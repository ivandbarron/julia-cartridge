#!/bin/bash
mvn compile exec:java
# requires maven and java 7
