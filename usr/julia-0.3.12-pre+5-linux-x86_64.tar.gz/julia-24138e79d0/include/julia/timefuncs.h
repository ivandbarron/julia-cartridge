#ifndef TIMEFUNCS_H
#define TIMEFUNCS_H

DLLEXPORT double clock_now(void);
void sleep_ms(int ms);

#endif
